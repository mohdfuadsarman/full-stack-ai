function addNumbers(a, b) {
    return a + b;
}

function printSum(a, b) {
    const sum = addNumbers(a, b);
    const resultElement = document.getElementById('result');
    resultElement.textContent = `The sum of ${a} and ${b} is ${sum}`;
}

function handleInput() {
    const num1 = parseInt(document.getElementById('num1').value, 10);
    const num2 = parseInt(document.getElementById('num2').value, 10);

    if (isNaN(num1) || isNaN(num2)) {
        document.getElementById('result').textContent = 'Please enter valid numbers.';
        return;
    }

    printSum(num1, num2);
}

// Attach the event listener to the button after the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('calculateButton');
    button.addEventListener('click', handleInput);
});
